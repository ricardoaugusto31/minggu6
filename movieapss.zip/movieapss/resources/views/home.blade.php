@extends('layouts.main')
@section('title', 'Home')
@section('content')
  <h3>HOME</h3>
  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
@endsection